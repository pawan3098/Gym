export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyDw_AqBWqoAOXQM-k8-iyLskrQaox_CnbA',
    authDomain: 'gym-registration-abhishek.firebaseapp.com',
    databaseURL: 'https://gym-registration-abhishek.firebaseio.com',
    projectId: 'gym-registration-abhishek',
    storageBucket: 'gym-registration-abhishek.appspot.com',
    messagingSenderId: '467435788154',
    appId: '1:467435788154:web:4902bd5ec36d76891668c3',
    measurementId: 'G-5BJ6562L3W',
  },
};
